package es.florida.MP2T1;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;

public class Controller {

	//Clase que incorpora los gestores de eventos(Listeners) a cada elemento de la vista.
	
	private View view;
	private Model model;
	
	//Constructor recibe instnacias de la vista y el modelo
	public Controller(View view, Model model) {
		this.model = model;
		this.view = view;
		initEventHandlers();
		
		
	}
	
	public void iniView() {
		
		view.initComponents();
		
		String textIni = "";
		for(String linea : model.readDocument(new File("ET1.txt"))) {
			textIni += linea+"\n";
		}
		view.setTextInfoDoc(textIni);
	}
	
	public void initEventHandlers() {
		view.btnSearch.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				System.out.println("Estoy entrando al pulsar el botón");
				
				String text = "";
				
				for(String lineas : model.readDocument(new File("ET1.txt"))) {
					text += lineas+"\n";
				}
				text += "La cantidad de coincidencias con la palabra seleccionada es: "+model.searchMatch(view.getSearchField());
				
				view.setTextInfoDoc(text);
			}
		});
	}
	

}
