package es.florida.MP2T1;

import java.io.*;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class Model {

	private List<String> lineasDoc;
	//Clase que gestiona los datos de la aplicación y permite las operaciones.
	
	public Model() {
		lineasDoc =  new ArrayList<String>();
		
	}
	
	public List<String> readDocument(File doc) {
		
		lineasDoc.clear();
		
		try {
			FileReader fR = new FileReader(doc);
			BufferedReader bR = new BufferedReader(fR);
			
			String linea = bR.readLine();
			
			while(linea != null) {
				lineasDoc.add(linea);
				bR.readLine();
			}
			
			bR.close();
			fR.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return lineasDoc;
	}
	
	public void writeDocument(File doc,List<String> newText) {
		
		try {
			FileWriter fW = new FileWriter(doc);
			BufferedWriter bW = new BufferedWriter(fW);
			
			for(String linea : newText) {
				bW.write(linea);
				bW.newLine();
			}
			
			bW.close();
			fW.close();
			
			
		} catch(IOException e) {
			e.printStackTrace();
		}
	}
	
	public int searchMatch(String word) {
		int count = 0;
		List<String> words = new ArrayList<String>();
		for(String linea : lineasDoc) {
			String[] sL = linea.split("[,.\\-:;!¡?¿ ]");
			for(String sW : sL) {
				words.add(sW);
			}
		}
		if(checkWord(word)) {
			for(String w : words) {
				if(word.toLowerCase().equals(w.toLowerCase())) {
					count++;
				}
			}
		} 
		
		return count;
	}
	
	public List<String> remplaceWord(String wordInDoc, String wordRemplace){
		List<String> lineaReplaced = new ArrayList<String>();
		if(checkWord(wordInDoc)) {
			for(String linea : lineasDoc) {
				lineaReplaced.add(linea.replaceAll("\\b"+wordInDoc+"\\b", wordRemplace));
			}
		}
		return lineaReplaced;
		
	}
	
	private Boolean checkWord(String word) {
		String[] check = word.split("[,.\\-:;!¡?¿ ]"); 
		if(check.length != 1) {
			return false;
		}else {
			return true;
		}
	}
	
	public List<String> getLineasDoc(){
		return lineasDoc;
	}
	
	
	
}
