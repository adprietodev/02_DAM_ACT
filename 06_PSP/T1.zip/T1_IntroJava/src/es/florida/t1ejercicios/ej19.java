package es.florida.t1ejercicios;

public class ej19 {

	public static void main(String[] args) {
		
		for(int i=0; i < 126; i++) {
			System.out.println("El caracter ASCII del numero "+(i+1)+" es: "+(char)i);
		}

	}

}
