package es.florida.t1ejercicios;

import java.util.Scanner;

public class ej01 {

	public static void main(String[] args) {
		
		int num1 = 4;
		int num2 = 32;
		
		System.out.print("La suma es "+(num1+num2));
		

	}

}
