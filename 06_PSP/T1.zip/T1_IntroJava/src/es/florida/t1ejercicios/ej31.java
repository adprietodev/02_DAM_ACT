package es.florida.t1ejercicios;

public class ej31 {

	public static void main(String[] args) {
		
		sayHello();

	}

	public static void sayHello() {
		System.out.println("Hola Mundo");
	}
}
